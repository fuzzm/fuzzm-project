/*

poisson2gauss.c

Converts poissonian distributed noise into gaussian distributed noise. 

*/

#include <stdio.h>
#include <math.h>

int main()
{
  float w;
  while (scanf("%f",&w) != EOF)
    printf("%f\n",2.0*sqrt(w+0.25109));    
  return 0;
}
