/*

edx2asc.c

The EDX-linescans are 16-bit tiff-images with one line containing 1024 pixels.
This program cuts off the tiff-header and converts the 16-bit integers into
ASCII-text.

*/

#include <stdio.h>
#include <math.h>

int main()
{
  int i,w;
  for(i=0;i<158;i++)
    getchar();
  for(i=0;i<1024;i++)
    {
      w=getchar();
      w=w*256+getchar();
      printf("%i\n",w);
    }    
  return 0;
}
