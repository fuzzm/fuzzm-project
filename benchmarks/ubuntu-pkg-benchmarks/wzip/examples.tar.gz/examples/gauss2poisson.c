/*

gauss2poisson.c

Converts gaussian distributed noise into poissonian distributed noise. 

*/

#include <stdio.h>
#include <math.h>

int main()
{
  float w;
  while (scanf("%f",&w) != EOF)
    {
      w=w/2.0;
      w=w*w;
      printf("%f\n",w);
    }    
  return 0;
}
