Command line used to find this crash:

./afl-fuzz -m8000M -i programs/0a0f242b77afe39fa5ff0cd579d7f6378b5869feae7ee792f416c9df19a5caf1-wasm/test-case -o programs/0a0f242b77afe39fa5ff0cd579d7f6378b5869feae7ee792f416c9df19a5caf1-wasm/findings -- programs/0a0f242b77afe39fa5ff0cd579d7f6378b5869feae7ee792f416c9df19a5caf1-wasm/prog.wasm.instr @@

If you can't reproduce a bug outside of afl-fuzz, be sure to set the same
memory limit. The limit used for this fuzzing session was 7.81 GB.

Need a tool to minimize test cases before investigating the crashes or sending
them to a vendor? Check out the afl-tmin that comes with the fuzzer!

Found any cool bugs in open-source tools using afl-fuzz? If yes, please drop
me a mail at <lcamtuf@coredump.cx> once the issues are fixed - I'd love to
add your finds to the gallery at:

  http://lcamtuf.coredump.cx/afl/

Thanks :-)
